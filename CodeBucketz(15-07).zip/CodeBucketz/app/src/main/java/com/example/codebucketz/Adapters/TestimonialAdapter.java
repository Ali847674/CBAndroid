package com.example.codebucketz.Adapters;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.codebucketz.R;

import java.util.List;

public class TestimonialAdapter extends PagerAdapter {

    private Context context;
    private List<Integer> imagestv;
    private List<String> comment;
    private List<String> name;
    private List<String> desig;

    public TestimonialAdapter( Context context, List<Integer> images, List<String> comment, List<String> name, List<String> designation ) {
        this.context = context;
        this.imagestv = images;
        this.comment = comment;
        this.name = name;
        this.desig = designation;
    }

    @Override
    public int getCount() {
        return imagestv.size();
    }

    @Override
    public boolean isViewFromObject( View view, Object object ) {
        return view == object;
    }

    @Override
    public Object instantiateItem( ViewGroup container, int position ) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.item_testimonial, null);

        ImageView images = view.findViewById(R.id.iv_testi);
        TextView names = view.findViewById(R.id.tv_name);
        TextView comments = view.findViewById(R.id.tv_comment);
        TextView designation = view.findViewById(R.id.tv_designation);

        LinearLayout linearLayout = view.findViewById(R.id.linearLayout);

        images.setImageResource(imagestv.get(position));
        names.setText(name.get(position));
        comments.setText(comment.get(position));
        designation.setText(desig.get(position));


        ViewPager viewPager = (ViewPager) container;
        viewPager.addView(view, 0);

        return view;
    }

    @Override
    public void destroyItem( ViewGroup container, int position, Object object ) {
        ViewPager viewPager = (ViewPager) container;
        View view = (View) object;
        viewPager.removeView(view);
    }
}
