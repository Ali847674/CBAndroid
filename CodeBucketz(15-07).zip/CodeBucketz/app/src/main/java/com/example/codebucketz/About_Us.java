package com.example.codebucketz;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.io.IOException;

public class About_Us extends Activity implements SurfaceHolder.Callback, MediaPlayer.OnPreparedListener, VideoControllerView.MediaPlayerControl {

    SurfaceView videoSurface;
    MediaPlayer player;
    VideoControllerView controller;
    Dialog dialog;
    TextView tv_dial_name, desc, desc2;
    Button btnFollow, bt_values, bt_vision, bt_mission;

    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about__us);

        bt_values = findViewById(R.id.bt_values);
        bt_vision = findViewById(R.id.bt_vision);
        bt_mission = findViewById(R.id.bt_mission);
        tv_dial_name = findViewById(R.id.tv_dial_name);
        desc = findViewById(R.id.tv_desc_one);
        desc2 = findViewById(R.id.tv_desc_two);




        ///

        bt_values.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Our Values", "We Offer High Quality Services", "We always try to bring something new and better for our customers. We don't depend on available traditional interfaces and designs. Our aim is to increase ease and control in applications.");
            }
        });

        bt_mission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Our Mission", "Solutions For Your Business", "Our mission is to enhancing the business growth of our customers with creative Designs & Development to deliver market-defining high-quality solutions that create values and reliable competitive advantage for our clients around the world.");


            }
        });

        bt_vision.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Our Vision", "Help Our Customer", "Our vision is to develop in a constant manner and grow as a major IT service provider to become a leading performer, in providing quality Web and Software Development solutions in the competitive local and global marketplace");

            }
        });

        ///


        videoSurface = findViewById(R.id.videoSurface);
        SurfaceHolder videoHolder = videoSurface.getHolder();
        videoHolder.addCallback(this);

        player = new MediaPlayer();
        controller = new VideoControllerView(this);

        try {
            player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            player.setDataSource(this, Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.code));
            player.setOnPreparedListener(this);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void customAlertNow( String name, String descc1, String descc2 ) {

        dialog = new Dialog(this);
        View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.custom_dialouge, null);

        dialog.setContentView(R.layout.custom_dialouge_2);

        tv_dial_name = dialog.findViewById(R.id.tv_dial_name);
        desc = dialog.findViewById(R.id.tv_desc_one);
        desc2 = dialog.findViewById(R.id.tv_desc_two);
        btnFollow = dialog.findViewById(R.id.btn_dial_follow);

        btnFollow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                dialog.dismiss();
            }
        });

        tv_dial_name.setText(name);
        desc.setText(descc1);
        desc2.setText(descc2);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

    }


    @Override
    public boolean onTouchEvent( MotionEvent event ) {
        controller.show();
        return false;
    }

    // Implement MediaPlayer.OnPreparedListener
    @Override
    public void onPrepared( MediaPlayer mp ) {
        controller.setMediaPlayer(this);
        controller.setAnchorView((FrameLayout) findViewById(R.id.videoSurfaceContainer));
        player.start();
    }
// End MediaPlayer.OnPreparedListener

    // Implement SurfaceHolder.Callback
    @Override
    public void surfaceChanged( SurfaceHolder holder, int format, int width, int height ) {

    }

    @Override
    public void surfaceCreated( SurfaceHolder holder ) {
        player.setDisplay(holder);
        player.prepareAsync();
    }

    @Override
    public void surfaceDestroyed( SurfaceHolder holder ) {

    }

    // End SurfaceHolder.Callback

    @Override
    public void start() {
        player.start();

    }

    @Override
    public void pause() {
        player.pause();

    }

    @Override
    public int getDuration() {
        return player.getDuration();
    }

    @Override
    public int getCurrentPosition() {
        return player.getCurrentPosition();
    }

    @Override
    public void seekTo( int pos ) {
        player.seekTo(pos);

    }

    @Override
    public boolean isPlaying() {
        return player.isPlaying();
    }

    @Override
    public int getBufferPercentage() {
        return 0;
    }

    @Override
    public boolean canPause() {
        return true;
    }

    @Override
    public boolean canSeekBackward() {
        return true;
    }

    @Override
    public boolean canSeekForward() {
        return true;
    }

    @Override
    public boolean isFullScreen() {
        return false;
    }

    @Override
    public void toggleFullScreen() {

    }
}
