package com.example.codebucketz;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.codebucketz.Adapters.SliderAdapter;
import com.example.codebucketz.Adapters.TestimonialAdapter;
import com.example.codebucketz.Adapters.TextAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomeNavigation extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    CardView cv_mobile, cv_web, cv_desktop, cv_brand;
    Dialog dialog;
    CircleImageView imageView;
    TextView nameService, desc;
    Button button;

    ViewPager viewPager, viewPager2, viewPager3;
    TabLayout indicator;

    List<Integer> color, imageTv;
    List<String> names, tv_name, tv_comment, tv_desig;
    private Object SUri;

    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_navigation);
        cv_mobile = findViewById(R.id.cv_mobile);
        cv_web = findViewById(R.id.cv_web);
        cv_desktop = findViewById(R.id.cv_desktop);
        cv_brand = findViewById(R.id.cv_branding);
        imageView = findViewById(R.id.iv_service_image);
        nameService = findViewById(R.id.tv_service_name);
        desc = findViewById(R.id.tv_service_desc);
        //


        cv_mobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Mobile Application", R.drawable.mobile_app, "Today’s era in the digital world is converging the growing need of mobile application & optimize the existing resources for Mobile users. We are now in the status to highlight the chances of achieving with our expert of the App Development Unit.");
            }
        });

        cv_web.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Web Application", R.drawable.web_development, "CodeBucketz is a Professional IT Solution Company having presence in Pakistan, our developers have successfully launched some top-ranking websites. What makes us unique is the fact, we never compromise on perfection.");
            }
        });

        cv_desktop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Desktop Application", R.drawable.desktop, "From smart customization of the pre-developed platforms to full-cycle custom software development along the client's vision, CodeBucketz is to deliver cost-effective and reliable custom software solutions that match your unique requirements.");
            }
        });

        cv_brand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Branding", R.drawable.branding, "Having an appropriate and effective brand identity can often be the difference between success and failure. CodeBucketz provides branding services offer clients the chance to create, develop and modify their brand identity properties such as logos etc.");
            }
        });


        //
        viewPager = findViewById(R.id.viewPager);
        viewPager2 = findViewById(R.id.viewPager2);
        viewPager3 = findViewById(R.id.viewPager3);
        indicator = findViewById(R.id.indicator);
        color = new ArrayList<>();
        color.add(R.drawable.slider1);
        color.add(R.drawable.slider2);
        color.add(R.drawable.slider3);

        names = new ArrayList<>();
        names.add("\"Make contact, Build Relationships, Get Results\"");
        names.add("\"We believe in mind blowing solutions\"");
        names.add("\"Your success matters to us\"");
        names.add("\"Sometimes the best way to envision the future is to invent it\"");


        tv_name = new ArrayList<>();
        tv_name.add("Krish Belasubramaniu");
        tv_name.add("S.U.BERLAS");


        tv_comment = new ArrayList<>();
        tv_comment.add("WoW. You guys rocked on that project! Thanks so much for doing a great job!");
        tv_comment.add("At a time of starting our setup we were quite worried about the branding of our institute, We saw work of Codebucketz  got impressed and ordered!!   It turns out the best experience ever, We highly recommend CODEBUCKETZ.");


        tv_desig = new ArrayList<>();
        tv_desig.add("Head Of DSL");
        tv_desig.add("CEO - LHRC");

        imageTv = new ArrayList<>();
        imageTv.add(R.drawable.testi1);
        imageTv.add(R.drawable.testi2);

        viewPager.setAdapter(new SliderAdapter(this, color));
        viewPager2.setAdapter(new TextAdapter(this, names));
        viewPager3.setAdapter(new TestimonialAdapter(this, imageTv, tv_comment, tv_name, tv_desig));
        indicator.setupWithViewPager(viewPager, true);

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new SliderTimer(), 4000, 6000);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View view ) {

                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:office_task@codebucketz.com"));
                intent.putExtra(Intent.EXTRA_SUBJECT, "Query");
                intent.putExtra(Intent.EXTRA_TEXT, "My query is ");
                startActivity(intent);

            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu( Menu menu ) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_navigation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected( MenuItem item ) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected( MenuItem item ) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {

        } else if (id == R.id.nav_about) {

            startActivity(new Intent(getApplicationContext(), About_Us.class));

        } else if (id == R.id.nav_profile) {

            startActivity(new Intent(getApplicationContext(), pdfViewer.class));


        } else if (id == R.id.nav_services) {

            startActivity(new Intent(getApplicationContext(), Services.class));


        } else if (id == R.id.nav_portfolio) {
            startActivity(new Intent(getApplicationContext(), Portfolio.class));

        } else if (id == R.id.nav_contact) {

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private class SliderTimer extends TimerTask {

        @Override
        public void run() {
            HomeNavigation.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (viewPager.getCurrentItem() < color.size() - 1) {
                        viewPager.setCurrentItem(viewPager.getCurrentItem() + 1);
                    } else {
                        try {
                            viewPager.setCurrentItem(0);
                        } catch (Exception E) {
                            Toast.makeText(HomeNavigation.this, "Restart Application", Toast.LENGTH_SHORT).show();
                        }

                    }

                    if (viewPager2.getCurrentItem() < names.size() - 1) {
                        viewPager2.setCurrentItem(viewPager2.getCurrentItem() + 1);
                    } else {
                        try {
                            viewPager2.setCurrentItem(0);
                        } catch (Exception E) {
                            Toast.makeText(HomeNavigation.this, "Restart Application", Toast.LENGTH_SHORT).show();
                        }

                    }

                    if (viewPager3.getCurrentItem() < imageTv.size() - 1) {
                        viewPager3.setCurrentItem(viewPager3.getCurrentItem() + 1);
                    } else {
                        try {
                            viewPager3.setCurrentItem(0);
                        } catch (Exception E) {
                            Toast.makeText(HomeNavigation.this, "Restart Application", Toast.LENGTH_SHORT).show();
                        }

                    }
                }
            });
        }
    }

    public void showMoreServices( View v ) {

        startActivity(new Intent(getApplicationContext(), Services.class));
    }

    public void customAlertNow( String name, Integer image, String descrr ) {

        dialog = new Dialog(this);
        View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.custom_dialouge, null);

        dialog.setContentView(R.layout.custom_dialouge);

        imageView = dialog.findViewById(R.id.iv_service_image);
        nameService = dialog.findViewById(R.id.tv_service_name);
        desc = dialog.findViewById(R.id.tv_service_desc);
        button = dialog.findViewById(R.id.btnfollow);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                dialog.dismiss();
            }
        });

        nameService.setText(name);
        imageView.setImageResource(image);
        desc.setText(descrr);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

    }

}

