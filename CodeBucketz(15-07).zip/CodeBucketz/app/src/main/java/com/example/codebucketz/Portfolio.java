package com.example.codebucketz;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

public class Portfolio extends AppCompatActivity {

    FrameLayout frameLayout;
    ImageView bt_port_all, bt_port_mobile, bt_port_web, bt_port_brand, bt_port_desktop, bt_port_video, bt_port_game;

    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_portfolio);

        bt_port_all = findViewById(R.id.bt_port_all);
        bt_port_mobile = findViewById(R.id.bt_port_mobile);
        bt_port_web = findViewById(R.id.bt_port_web);
        bt_port_brand = findViewById(R.id.bt_port_brand);
        bt_port_desktop = findViewById(R.id.bt_port_desktop);
        bt_port_video = findViewById(R.id.bt_port_video);
        bt_port_game = findViewById(R.id.bt_port_game);
        frameLayout = findViewById(R.id.port_container);
        
        
        bt_port_all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                getSupportFragmentManager().beginTransaction().replace(R.id.port_container, new FragmentMobilePortfolio()).addToBackStack("Home").commit();
            }
        });
    }
}
