package com.example.codebucketz;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import de.hdodenhof.circleimageview.CircleImageView;

public class Services extends AppCompatActivity {

    CardView cv_mobile, cv_web, cv_desktop, cv_brand, cv_ecommerce, cv_wordpress, cv_game, cv_editing;
    AlertDialog.Builder builder;
    Dialog dialog;
    CircleImageView imageView;
    static TextView nameService, desc;
    Button button;

    public Services() {
    }

    @Override
    protected void onCreate( Bundle savedInstanceState ) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services);
        View viewCustom = LayoutInflater.from(getApplicationContext()).inflate(R.layout.custom_dialouge, null);

        cv_mobile = findViewById(R.id.cv_mobile);
        builder = new AlertDialog.Builder(this);
        cv_web = findViewById(R.id.cv_web);
        cv_desktop = findViewById(R.id.cv_desktop);
        cv_brand = findViewById(R.id.cv_branding);
        cv_ecommerce = findViewById(R.id.cv_ecommerce);
        cv_wordpress = findViewById(R.id.cv_wordpress);
        cv_game = findViewById(R.id.cv_gaming);
        cv_editing = findViewById(R.id.cv_editing);
        imageView = findViewById(R.id.iv_service_image);
        nameService = findViewById(R.id.tv_service_name);
        desc = findViewById(R.id.tv_service_desc);
//        button = dialog.findViewById(R.id.btnFollow);
//        button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick( View v ) {
//                Toast.makeText(Services.this, "asdasdasd", Toast.LENGTH_SHORT).show();
//            }
//        });

        cv_mobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Mobile Application", R.drawable.mobile_app, "Today’s era in the digital world is converging the growing need of mobile application & optimize the existing resources for Mobile users. We are now in the status to highlight the chances of achieving with our expert of the App Development Unit.");
            }
        });

        cv_web.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Web Application", R.drawable.web_development, "CodeBucketz is a Professional IT Solution Company having presence in Pakistan, our developers have successfully launched some top-ranking websites. What makes us unique is the fact, we never compromise on perfection.");
            }
        });

        cv_desktop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Desktop Application", R.drawable.desktop, "From smart customization of the pre-developed platforms to full-cycle custom software development along the client's vision, CodeBucketz is to deliver cost-effective and reliable custom software solutions that match your unique requirements.");
            }
        });

        cv_brand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Branding", R.drawable.branding, "Having an appropriate and effective brand identity can often be the difference between success and failure. CodeBucketz provides branding services offer clients the chance to create, develop and modify their brand identity properties such as logos etc.");
            }
        });

        cv_ecommerce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("E-Commerce", R.drawable.ecommerce, "An integrated e-commerce system is the backbone of any great business online. However, it can be a difficult task to take on effectively. Luckily, CodeBucketz is here to help. There’s no limit to what your business can achieve with a powerful e-commerce system.");
            }
        });

        cv_wordpress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Wordpress", R.drawable.web_wordpress, "CodeBucketz provides customer centric WordPress website solutions. With our competitively priced WordPress services, get true value for your business. The services are characterized by scalability, better quality and pixel perfect designs.");
            }
        });

        cv_game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Game Application", R.drawable.web_development, "We have designed and developed multiple successful 3D graphics, imaging and visualization applications for our partners. We make cross platform 3D apps using Unity3D and high performance desktop apps using OpenGL/C++.");
            }
        });

        cv_editing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                customAlertNow("Video Editing/Animation", R.drawable.video_editing, "Our team of animation mavericks transform monotonous images into engaging motion graphic videos and purposeful whiteboard animations that work to enhance business reputations worldwide. Our expertise is persuasion, we can bring you the response you need.");
            }
        });


    }

    public void customAlertNow( String name, Integer image, String descrr ) {

        dialog = new Dialog(this);
        View view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.custom_dialouge, null);

        dialog.setContentView(R.layout.custom_dialouge);

        imageView = dialog.findViewById(R.id.iv_service_image);
        nameService = dialog.findViewById(R.id.tv_service_name);
        desc = dialog.findViewById(R.id.tv_service_desc);
        button = dialog.findViewById(R.id.btnfollow);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick( View v ) {
                dialog.dismiss();
            }
        });

        nameService.setText(name);
        imageView.setImageResource(image);
        desc.setText(descrr);

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();

    }
}
